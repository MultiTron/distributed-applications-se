﻿using Microsoft.AspNetCore.Mvc;

namespace FL.Website.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
