﻿namespace FL.Website.Models
{
    public class TokenModel
    {
        public string? Token { get; set; }
    }
}
