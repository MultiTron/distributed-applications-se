﻿namespace FL.Infrastructure.Messaging
{
    public abstract class ServiceRequestBase
    {

    }
}
