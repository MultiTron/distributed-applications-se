﻿namespace FL.Infrastructure.Messaging
{
    public enum BussinesStatusCodeEnum
    {
        Success = 0,
        InternalServerError = 500,
    }
}
