﻿namespace FL.Infrastructure.Messaging
{
    public class AuthOptions
    {
        required public string TokenKey { get; set; }
    }
}
