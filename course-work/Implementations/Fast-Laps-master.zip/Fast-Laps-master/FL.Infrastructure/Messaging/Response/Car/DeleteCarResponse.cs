﻿namespace FL.Infrastructure.Messaging.Response
{
    public class DeleteCarResponse : ServiceResponseBase
    {
    }
}
