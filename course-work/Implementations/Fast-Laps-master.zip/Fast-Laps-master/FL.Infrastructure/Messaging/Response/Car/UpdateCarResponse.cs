﻿namespace FL.Infrastructure.Messaging.Response.Car
{
    public class UpdateCarResponse : ServiceResponseBase
    {
    }
}
