﻿namespace FL.Infrastructure.Messaging.Response
{
    public class CreateCarResponse : ServiceResponseBase
    {
    }
}
