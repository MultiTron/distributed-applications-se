﻿namespace FL.Infrastructure.Messaging.Response.Auth
{
    public class TokenResponse : ServiceResponseBase
    {
        public string? Token { get; set; }
    }
}
