﻿namespace FL.Infrastructure.Messaging.Response.Lap
{
    public class CreateLapResponse : ServiceResponseBase
    {
    }
}
