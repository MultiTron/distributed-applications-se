﻿namespace FL.Infrastructure.Messaging.Response.Lap
{
    public class UpdateLapResponse : ServiceResponseBase
    {
    }
}
