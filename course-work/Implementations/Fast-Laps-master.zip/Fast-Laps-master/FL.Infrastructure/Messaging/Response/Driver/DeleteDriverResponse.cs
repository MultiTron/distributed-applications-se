﻿namespace FL.Infrastructure.Messaging.Response.Driver
{
    public class DeleteDriverResponse : ServiceResponseBase
    {
    }
}
