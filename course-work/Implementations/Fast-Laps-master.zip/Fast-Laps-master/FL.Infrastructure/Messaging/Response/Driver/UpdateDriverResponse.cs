﻿namespace FL.Infrastructure.Messaging.Response.Driver
{
    public class UpdateDriverResponse : ServiceResponseBase
    {
    }
}
