﻿namespace FL.Infrastructure.Messaging.Response.Driver
{
    public class CreateDriverResponse : ServiceResponseBase
    {
    }
}
