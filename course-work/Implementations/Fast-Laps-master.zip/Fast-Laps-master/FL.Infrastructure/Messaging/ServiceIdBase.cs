﻿namespace FL.Infrastructure.Messaging
{
    public class ServiceIdBase
    {
        public int Id { get; set; }
        public ServiceIdBase(int id)
        {
            Id = id;
        }
    }
}
