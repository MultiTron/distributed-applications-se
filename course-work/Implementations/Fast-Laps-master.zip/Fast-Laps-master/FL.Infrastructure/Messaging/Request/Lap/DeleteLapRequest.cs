﻿namespace FL.Infrastructure.Messaging.Request.Lap
{
    public class DeleteLapRequest : ServiceIdBase
    {
        public DeleteLapRequest(int id) : base(id)
        {
        }
    }
}
