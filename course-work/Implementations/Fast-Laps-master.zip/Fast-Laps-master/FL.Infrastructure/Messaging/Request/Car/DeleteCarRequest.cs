﻿namespace FL.Infrastructure.Messaging.Request
{
    public class DeleteCarRequest : ServiceIdBase
    {
        public DeleteCarRequest(int id) : base(id)
        {
        }
    }
}
