﻿namespace FL.Infrastructure.Messaging.Request.Driver
{
    public class DeleteDriverRequest : ServiceIdBase
    {
        public DeleteDriverRequest(int id) : base(id)
        {
        }
    }
}
